﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SeleniumTax
{
    class Program
    {
        static void Main(string[] args)
        {
            IWebDriver driver = new ChromeDriver();

            driver.Navigate().GoToUrl("https://www.tax.service.gov.uk/estimate-paye-take-home-pay/your-pay");

            //ASSERTION
            string title = driver.Title;
            Assert.AreEqual(true, title.Contains("How much do you get paid??"), "Title is not matching");

            //wait for 2 seconds
            waitOnPage(2);
            
            //Find Amount Element
            IWebElement element = driver.FindElement(By.Name("amount"));


            //INSERT AMOUNT
            element.SendKeys("22000");

            //wait for 2 seconds
            waitOnPage(2);

            //CLICK an hour
            IWebElement hourly = driver.FindElement(By.Id("hourly"));
            hourly.Click();

            
            //Wait 2 seconds
            waitOnPage(2);

            //click a month
            IWebElement monthly = driver.FindElement(By.Id("monthly"));
            monthly.Click();

            //Wait 2 seconds
            waitOnPage(2);

            //click a week
            IWebElement weekly = driver.FindElement(By.Id("weekly"));
            weekly.Click();

            //wait 2 seconds
            waitOnPage(2);
            
            //click a day
            IWebElement daily = driver.FindElement(By.Id("daily"));
            daily.Click();

            //wait 2 seconds
            waitOnPage(2);

            //click a year
            IWebElement yearly = driver.FindElement(By.Id("yearly"));
            yearly.Click();

            //wait 2 seconds
            waitOnPage(2);

            //Click Continue
            IWebElement Continue = driver.FindElement(By.Id("p-continue"));
            Continue.Click();

            //-------------------------------------------
            //ARE YOU OVER THE STATE PENSION AGE

            //ASSERTION
            string titleTwo = driver.Title;
            Assert.AreEqual(true, titleTwo.Contains("Are you over the State Pension age?"), "Title is not matching");

            //CLICK NO
            IWebElement Nope = driver.FindElement(By.Id("over-state-pension-age-no"));
            Nope.Click();

            //wait 2 seconds
            waitOnPage(2);

            //CLICK CONTINUE
            IWebElement ContinueAgain = driver.FindElement(By.Id("sp-continue"));
            ContinueAgain.Click();

            //--------------------------------------------------
            //DO YOU WANT TO USE YOUR CURRENT TAX CODE?

            //ASSERTION
            string titleThree = driver.Title;
            Assert.AreEqual(true, titleThree.Contains("Do you want to use your current tax code?"), "Title is not matching");

            //CLICK NO
            IWebElement NO = driver.FindElement(By.Id("tax-code-no"));
            NO.Click();

            //wait 2 seconds
            waitOnPage(2);

            //CLICK CONTINUE
            IWebElement Continue3 = driver.FindElement(By.Id("tc-continue"));
            Continue3.Click();

            //-----------------------------------------
            //DO YOU PAY THE SCOTTISH INCOME TAX RATE?

            //ASSERTION
            string titleFour = driver.Title;
            Assert.AreEqual(true, titleFour.Contains("Do you pay the Scottish Income Tax Rate?"), "Title is not matching");

            //Wait 5 seconds
            waitOnPage(5);

            //CLICK CONTINUE STRAIGHTAWAY
            IWebElement Continue4 = driver.FindElement(By.Id("sr-continue"));
            Continue4.Click();

            //ERROR MESSAGE, WAIT 5 seconds to show it
            waitOnPage(5);

            //CLICK YES
            IWebElement Continue5 = driver.FindElement(By.Id("scottish-rate-yes"));
            Continue5.Click();

            //WAIT 5 seconds
            waitOnPage(5);

            //Click continue now
            IWebElement Continue6 = driver.FindElement(By.Id("sr-continue"));
            Continue6.Click();

            //------------------------
            //Check your answers
           

            //ASSERTION
            string titleFive = driver.Title;
            Assert.AreEqual(true, titleFive.Contains("Check your answers"), "Title is not matching");
            waitOnPage(5);

            //--------------------------
            //clicking back
            IWebElement Continue7 = driver.FindElement(By.Id("tc-back"));
            Continue7.Click();

            //WAIT 5 seconds
            waitOnPage(5);

            //ASSERTION
            string titleSix = driver.Title;
            Assert.AreEqual(true, titleSix.Contains("Do you pay the Scottish Income Tax Rate?"), "Title is not matching");

            //CLICK NO
            IWebElement Continue8 = driver.FindElement(By.Id("scottish-rate-no"));
            Continue8.Click();

            waitOnPage(5);

            //Click continue now
            IWebElement Continue9 = driver.FindElement(By.Id("sr-continue"));
            Continue9.Click();

            //-------------------
            string titleSeven = driver.Title;
            Assert.AreEqual(true, titleSeven.Contains("Check your answers"), "Title is not matching");
            waitOnPage(5);
            IWebElement Continue10 = driver.FindElement(By.Id("get-results"));
            Continue10.Click();
            waitOnPage(5);

            driver.Close();
            
        }


        //static void Continued()
        //{

        //   IWebElement Continue4 = driver.FindElement(By.Id("sr-continue"));
        //   Continue4.Click();
        // }

        public static void waitOnPage(int seconds)
        {
            System.Threading.Thread.Sleep(seconds * 1000);
        }

       
    }

}



  

   

